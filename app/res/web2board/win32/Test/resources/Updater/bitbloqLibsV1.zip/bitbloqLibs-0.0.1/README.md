# bitbloqLibs
Arduino libraries being used by [bitbloq](http://bitbloq.bq.com)

Use it with the Arduino IDE
---------------
In order to use these libraries with the Arduino IDE, clone this repo inside your sketchbook/libraries/ folder. Then, you are ready to go!

## How to contribute

- Clone project
   ```
   git clone http://github.com/bq/bitbloqLibs.git
   ```
- Add your library and the examples you deem necessary
- Make a pull request to this repository with your changes.  [How to create a pull request](https://help.github.com/articles/creating-a-pull-request/).
